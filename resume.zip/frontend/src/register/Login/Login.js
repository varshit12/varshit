import React, { useState } from 'react';
import axios from 'axios';
import './Login.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const Submit=async() =>{
    try{
     const result = await axios.post("http://localhost:8000/login/"+email+'/'+password);
     console.log(result)
        if(result.data)
        {
            alert("Successfully stored");
        }
        else{
            alert("try again");
        }
    }
    catch(e)
    {
     console.log(e);
    }
    
 }


  const handleSubmit = (e) => {
    e.preventDefault(e);
    // You can perform login validation here
    console.log('Login clicked');
  };

  return (
    <div className="App">
      <section>
        <div className="login-box">
          <p>Login</p>
          <form onSubmit={handleSubmit}>
            <div className="user-box">
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <label>Email</label>
            </div>
            <div className="user-box">
              <input
                required
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <label>Password</label>
            </div>
            <button onClick="submit">Submit</button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Login;
